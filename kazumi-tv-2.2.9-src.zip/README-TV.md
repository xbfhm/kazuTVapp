# KazumiTV —— 安卓 5.1 电视版套壳（基于 Kazumi 2.2.9）

针对 **海信 VIDAA V1**（MStar MSD6A828 / Android 5.1.1 / API 22 / 2GB 内存 / arm64-v8a，双架构保险）适配的 Kazumi 电视版。
保留 Kazumi 全部主要功能：**番剧搜索 / 目录 / 时间表 / 追番 / 历史 / 播放器（播放、暂停、快进、快退、倍速、弹幕、选集）**，使用 Kazumi 规则源在线采集看番。

---

## 一、本版已做的适配（相对官方 Kazumi 2.2.9 的改动）

| 项目 | 说明 |
|---|---|
| **minSdk 21** | 官方 Flutter 3.47 默认 minSdk=24（安卓 7.0），不改装不上安卓 5.1；已显式锁定 **21（安卓 5.0+）**，API 22 电视可安装 |
| **关闭 Impeller** | 官方已默认关闭（`EnableImpeller=false`），强制 Skia 渲染，兼容 Mali-450 老 GPU，避免闪退 |
| **双架构 fat APK** | 构建时同时打进 `arm64-v8a` + `armeabi-v7a`，64/32 位镜像都能装 |
| **内置 83 个规则源** | 把 KazumiRules 全部规则内置到 `assets/plugins/`，首次启动**自动安装**，开箱即用，无需手动导入 |
| **遥控器按键** | OK/确定=播放暂停；左右=快进快退（长按快进连发）；上下=音量；频道±=上/下一集；BACK=退出 |
| **初始焦点** | 应用启动自动落焦点，遥控器方向键即可操作，无需先点屏幕 |
| **自动更新默认关** | 避免套壳版被引导去装官方版（设置里可手动打开） |
| **应用 ID** | `com.kazumi.tv`，可与官方 Kazumi 共存安装 |
| **应用名** | KazumiTV |

---

## 二、GitHub 云端打包步骤（无需电脑，手机浏览器即可）

1. **建仓库**（或复用旧仓库，建议新建）：GitHub 网页 → 右上角 `+` → New repository（名字随意，Public/Private 都行）→ Create。
2. **上传源码包**：仓库首页 → `Add file` → `Upload files` → 把 `kazumi-tv-2.2.9-src.zip` 拖进来 → `Commit changes`。
3. **上传构建脚本**：仓库首页 → `Add file` → `Create new file` → 文件名填 `.github/workflows/build.yml` → 把本目录 `build.yml` 的内容整段粘贴进去 → `Commit changes`。
   > 也可以用 `Add file → Upload files` 直接上传 `build.yml`，但要先建好 `.github/workflows/` 目录层级。
4. 打开仓库的 **Actions** 页：第 3 步的提交会自动触发 `Build KazumiTV APK`；也可以随时手动点 `Run workflow` 重新构建。
5. 等 10~25 分钟（首次较慢，之后有缓存会快）→ 点进本次运行 → 最底部 **Artifacts** → 下载 **`kazumi-tv-apk`**，解压得到 APK → 拷到 U 盘/网盘安装到电视。
   > 手机浏览器下载 Actions 工件：直接点 Artifacts 下载即可（无需登录工具）。

**以后更新**：把新版本 `kazumi-tv-*.zip` 上传覆盖仓库根目录同名文件 → Actions 自动重新构建，脚本不用再动。

---

## 三、电视遥控器操作指南

| 按键 | 功能 |
|---|---|
| **OK/确定** | 播放页：播放/暂停（控制条展开且焦点在按钮上时，OK 为确认按钮）；列表页：进入/确认 |
| **←/→** | 播放页：快退/快进（每次约 10 秒，→ 长按持续快进）；列表页：左右移动焦点 |
| **↑/↓** | 音量加减；列表页：上下移动焦点 |
| **频道+/频道−** | 播放页：下一集/上一集 |
| **BACK/返回** | 播放页退出；主界面：返回上一级，再按一次退出应用 |
| **数字 1/2/3** | 播放页：1x / 2x / 3x 倍速（可在 设置→快捷键 里自定义） |

> 所有快捷键可在 App 内 `我的 → 设置 → 快捷键` 中修改。

---

## 四、常见问题

**Q1：构建失败，提示 `minSdkVersion 21 cannot be smaller than version 23 declared in library ...`**
说明某个依赖库升级到了 minSdk 23。打开 `android/app/build.gradle`，在已有的
`resolutionStrategy { force ... }` 列表里按同样格式把报错的那个库强制到 minSdk≤21 的版本即可
（常见：`force 'androidx.appcompat:appcompat:1.7.1'`、`force 'com.google.android.material:material:1.13.0'`）。
**注意**：minSdk 不要改大，改大了电视就装不上了。

**Q2：某个番剧源加载失败/播放不了**
内置的 83 个规则来自 Kazumi 官方规则仓库，部分站点可能失效。到 App 内 `我的 → 规则管理`：
- 点右上角更新按钮，从官方规则仓库拉最新规则；
- 或在"规则商店"里单独安装/更新需要的源；
- 也可手动导入网上分享的规则 JSON。

**Q3：电视上搜索框不弹键盘**
部分电视（尤其精简过的 VIDAA）没有系统输入法。建议用 App 的**时间表/追番/推荐**浏览找番；
或装一个第三方输入法（如 TV 版讯飞）后再用搜索。这是 Flutter 电视端的通用限制，不影响看番主流程。

**Q4：播放卡顿/花屏**
老电视软解能力有限。播放页 → 设置 → 把**画质**调低（如 720p/480p）；倍速播放建议保持 1x；
弹幕过多时可在播放页关闭弹幕（遥控器 D 键或设置里改键）。

**Q5：官方 Kazumi 出新版了，我这个能升级吗？**
本套壳是独立应用（com.kazumi.tv），官方新版安装包**不能**直接覆盖升级。
想要新功能时，等我把新版本重新适配后给你新的 zip，按第二节流程上传即可。

**Q7：电视安装时报"版本太高"/无法安装（重点排查）**
先分清你装的是哪个 APK：
- ❌ **官方 Kazumi 的 APK**（Kazumi 官网/Releases 页下载的）要求**安卓 7.0+**，你的 5.1 电视必然报"版本太高"。它和本套壳无关。
- ✅ **本套壳的 APK** = 你 GitHub Actions 构建产物 `kazumi-tv-apk` 工件里的 `app-release.apk`，minSdk=21（安卓 5.0+），双架构（32/64 位都含），**能装 5.1 电视**。

构建日志自证：本次新版构建脚本在"Upload APK"前多了一步 **Verify APK (minSdk + ABI)**，日志里会打印：
```
sdkVersion:'21'
native-code: 'armeabi-v7a' 'arm64-v8a'
```
看到这两行就说明 APK 确实是电视兼容版。

还想排除电视本身的问题，用甲壳虫ADB 连上电视后在"命令"里跑两条：
```
getprop ro.build.version.sdk     # 应为 22（安卓5.1）；若低于21说明系统不是5.1
getprop ro.product.cpu.abi       # armeabi-v7a 或 arm64-v8a，两者本 APK 都支持
```
把结果发给我即可确认。

**Q6：想改应用名/图标**
- 应用名：`android/app/src/main/AndroidManifest.xml` 里 `android:label="KazumiTV"` 改成你想要的；
- 图标：把 `assets/images/logo/` 下的图片换成你的图（保持同名同尺寸），构建时会自动生成。

---

## 五、工程说明

- 基于官方 [Kazumi](https://github.com/Predidit/Kazumi)（v2.2.9，Flutter 3.47.1 / Dart 3.13）二次开发；
- 所有改动点都有 `// 电视版适配` / `// 电视遥控器` 中文注释，方便对照官方差异；
- 构建产物：`app-release.apk`（fat APK，含 arm64 + arm，约 90~130MB，属于正常体积）。
