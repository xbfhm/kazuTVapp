import 'dart:async';

import 'package:kazumi/services/video_source/video_source_format.dart';

/// 视频源类型
enum VideoSourceType {
  /// 在线解析（WebView）
  online,

  /// 本地缓存
  cached,
}

/// 视频源解析结果
class VideoSource {
  /// 视频 URL (M3U8/MP4/本地路径)
  final String url;

  /// 播放偏移量（秒）
  final int offset;

  /// 视频源类型
  final VideoSourceType type;

  /// 解析视频源时确认的媒体格式提示
  final VideoSourceFormat format;

  const VideoSource({
    required this.url,
    required this.offset,
    required this.type,
    this.format = VideoSourceFormat.auto,
  });

  @override
  String toString() =>
      'VideoSource(url: $url, offset: $offset, type: $type, format: $format)';
}

/// 视频源未找到异常
class VideoSourceNotFoundException implements Exception {
  final String message;
  const VideoSourceNotFoundException([this.message = 'Video source not found']);

  @override
  String toString() => 'VideoSourceNotFoundException: $message';
}

/// 视频源解析超时异常
class VideoSourceTimeoutException implements Exception {
  final Duration timeout;
  const VideoSourceTimeoutException(this.timeout);

  @override
  String toString() =>
      'VideoSourceTimeoutException: Timed out after ${timeout.inSeconds}s';
}

/// 视频源解析取消异常
class VideoSourceCancelledException implements Exception {
  const VideoSourceCancelledException();

  @override
  String toString() =>
      'VideoSourceCancelledException: Resolution was cancelled';
}

/// 视频源解析服务接口
///
/// 抽象视频源的获取方式，支持多种实现：
/// - WebView 解析（在线）
/// - 本地缓存读取
/// - 组合策略（优先缓存，回退 WebView）
abstract class IVideoSourceService {
  /// 解析视频源 URL
  ///
  /// [episodeUrl] 集数页面 URL
  /// [useLegacyParser] 是否使用旧版解析器（iframe 监听）
  /// [offset] 播放偏移量（秒）
  /// [timeout] 解析超时时间
  ///
  /// 返回 [VideoSource] 包含解析后的视频 URL 和元数据
  ///
  /// 可能抛出：
  /// - [VideoSourceNotFoundException] 未找到视频源
  /// - [VideoSourceTimeoutException] 解析超时
  /// - [VideoSourceCancelledException] 解析被取消
  Future<VideoSource> resolve(
    String episodeUrl, {
    required bool useLegacyParser,
    int offset = 0,
    Duration timeout = const Duration(seconds: 30),
  });

  /// 取消当前正在进行的解析
  ///
  /// 调用后，正在进行的 [resolve] 会抛出 [VideoSourceCancelledException]
  void cancel();

  /// 释放资源
  Future<void> dispose();
}
