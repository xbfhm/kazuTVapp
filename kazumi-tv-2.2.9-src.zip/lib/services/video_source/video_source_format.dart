enum VideoSourceFormat {
  auto,
  hls,
}
