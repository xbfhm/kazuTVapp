import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kazumi/bean/widget/play_pause_icon.dart';
import 'package:kazumi/pages/player/player_adjustment_hud.dart';
import 'package:kazumi/pages/player/controller/player_aspect_ratio.dart';
import 'package:kazumi/pages/player/controller/player_super_resolution.dart';
import 'package:kazumi/bean/widget/embedded_native_control_area.dart';
import 'package:kazumi/pages/player/player_panel_hold.dart';
import 'package:kazumi/services/player/pip_utils.dart';
import 'package:kazumi/pages/video/video_controller.dart';
import 'package:kazumi/bean/dialog/dialog_helper.dart';
import 'package:kazumi/pages/player/player_controller.dart';
import 'package:flutter/services.dart';
import 'package:kazumi/services/player/remote.dart';
import 'package:kazumi/bean/appbar/drag_to_move_bar.dart' as dtb;
import 'package:kazumi/pages/settings/danmaku/danmaku_settings_sheet.dart';
import 'package:kazumi/utils/constants.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:kazumi/services/player/timed_shutdown_service.dart';
import 'package:kazumi/pages/download/download_controller.dart';
import 'package:kazumi/utils/device.dart';
import 'package:kazumi/utils/format.dart';

class PlayerItemPanel extends StatefulWidget {
  const PlayerItemPanel({
    super.key,
    required this.playerController,
    required this.videoPageController,
    required this.onBackPressed,
    required this.setPlaybackSpeed,
    required this.showDanmakuSwitch,
    required this.changeEpisode,
    required this.handleFullscreen,
    required this.enterAndroidPictureInPicture,
    required this.handleScreenShot,
    required this.handlePreNextEpisode,
    required this.handleProgressBarDragStart,
    required this.handleProgressBarSeek,
    required this.handleSuperResolutionChange,
    required this.panelVisibilityController,
    required this.toggleMenu,
    required this.keyboardFocus,
    required this.sendDanmaku,
    required this.acquirePlayerPanelHold,
    required this.onMenuVisibilityChanged,
    required this.handleDanmaku,
    required this.skipOP,
    required this.showVideoInfo,
    required this.showSyncPlayPanel,
    required this.showDanmakuDestinationPickerAndSend,
    required this.pauseForTimedShutdown,
    this.disableAnimations = false,
  });

  final PlayerController playerController;
  final VideoPageController videoPageController;
  final void Function(BuildContext) onBackPressed;
  final Future<void> Function(double) setPlaybackSpeed;
  final void Function() showDanmakuSwitch;
  final Future<void> Function(int, {int currentRoad, int offset}) changeEpisode;
  final void Function() toggleMenu;
  final void Function() handleFullscreen;
  final Future<void> Function() enterAndroidPictureInPicture;
  final void Function() handleScreenShot;
  final VoidCallback handleProgressBarDragStart;
  final Future<void> Function(Duration duration) handleProgressBarSeek;
  final Future<void> Function(SuperResolutionMode mode)
      handleSuperResolutionChange;
  final AnimationController panelVisibilityController;
  final FocusNode keyboardFocus;
  final PlayerPanelHold Function() acquirePlayerPanelHold;
  final ValueChanged<bool> onMenuVisibilityChanged;
  final void Function() handleDanmaku;
  final void Function(String direction) handlePreNextEpisode;
  final void Function() skipOP;
  final bool Function(String) sendDanmaku;
  final void Function() showVideoInfo;
  final void Function() showSyncPlayPanel;
  final Future<bool> Function(String) showDanmakuDestinationPickerAndSend;
  final VoidCallback pauseForTimedShutdown;
  final bool disableAnimations;

  @override
  State<PlayerItemPanel> createState() => _PlayerItemPanelState();
}

class _PlayerItemPanelState extends State<PlayerItemPanel> {
  late Animation<Offset> topOffsetAnimation;
  late Animation<Offset> bottomOffsetAnimation;
  late Animation<Offset> leftOffsetAnimation;
  late final VideoPageController videoPageController =
      widget.videoPageController;
  late final PlayerController playerController;
  final DownloadController downloadController = inject<DownloadController>();
  final TextEditingController textController = TextEditingController();
  final FocusNode textFieldFocus = FocusNode();
  PlayerPanelHold? _danmakuTextFieldHold;

  String? cachedSvgString;
  Widget? cachedDanmakuOnIcon;
  Widget? cachedDanmakuOffIcon;
  Widget? cachedDanmakuSettingIcon;

  static const double _danmakuIconSize = 24.0;
  static const double _loadingIndicatorStrokeWidth = 2.0;

  @override
  void dispose() {
    _releaseDanmakuTextFieldPanel();
    textController.dispose();
    textFieldFocus.dispose();
    super.dispose();
  }

  void _holdDanmakuTextFieldPanel() {
    if (_danmakuTextFieldHold?.isReleased == false) {
      return;
    }
    _danmakuTextFieldHold = widget.acquirePlayerPanelHold();
  }

  void _releaseDanmakuTextFieldPanel() {
    _danmakuTextFieldHold?.release();
    _danmakuTextFieldHold = null;
  }

  Future<void> _submitDanmakuText(String message) async {
    textFieldFocus.unfocus();
    _releaseDanmakuTextFieldPanel();

    final sent = await widget.showDanmakuDestinationPickerAndSend(message);
    if (!mounted) {
      return;
    }
    if (sent) {
      textController.clear();
    }
  }

  Widget get danmakuTextField {
    return Observer(builder: (context) {
      return Container(
        constraints: isDesktop()
            ? const BoxConstraints(maxWidth: 500, maxHeight: 33)
            : const BoxConstraints(maxHeight: 33),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: TextField(
          focusNode: textFieldFocus,
          style:
              TextStyle(fontSize: isDesktop() ? 15 : 13, color: Colors.white),
          controller: textController,
          textAlignVertical: TextAlignVertical.center,
          decoration: InputDecoration(
            enabled: playerController.danmaku.danmakuOn,
            filled: true,
            fillColor: Colors.white38,
            floatingLabelBehavior: FloatingLabelBehavior.never,
            hintText:
                playerController.danmaku.danmakuOn ? '发个友善的弹幕见证当下' : '已关闭弹幕',
            hintStyle: TextStyle(
                fontSize: isDesktop() ? 15 : 13, color: Colors.white60),
            alignLabelWithHint: true,
            contentPadding: EdgeInsets.symmetric(
                vertical: 8, horizontal: isDesktop() ? 8 : 12),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius:
                  BorderRadius.all(Radius.circular(isDesktop() ? 8 : 20)),
            ),
            suffixIconConstraints: const BoxConstraints(minWidth: 0),
            suffixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(
                  onPressed: () {
                    unawaited(_submitDanmakuText(textController.text));
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: playerController.danmaku.danmakuOn
                        ? Theme.of(context).colorScheme.onPrimaryContainer
                        : Colors.white60,
                    backgroundColor: playerController.danmaku.danmakuOn
                        ? Theme.of(context).colorScheme.primaryContainer
                        : Theme.of(context).disabledColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(isDesktop() ? 8 : 20),
                    ),
                  ),
                  child: const Text('发送'),
                ),
              ],
            ),
          ),
          onTapAlwaysCalled: true,
          onTap: () {
            _holdDanmakuTextFieldPanel();
          },
          onSubmitted: (msg) {
            unawaited(_submitDanmakuText(msg));
          },
          onTapOutside: (_) {
            _releaseDanmakuTextFieldPanel();
            textFieldFocus.unfocus();
            widget.keyboardFocus.requestFocus();
          },
        ),
      );
    });
  }

  void showSetSpeedSheet() {
    final double currentSpeed = playerController.playback.playerSpeed;
    KazumiDialog.show(builder: (context) {
      return AlertDialog(
        title: const Text('播放速度'),
        content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Wrap(
            spacing: 8,
            runSpacing: isDesktop() ? 8 : 0,
            children: [
              for (final double i in defaultPlaySpeedList) ...<Widget>[
                if (i == currentSpeed)
                  FilledButton(
                    onPressed: () async {
                      await widget.setPlaybackSpeed(i);
                      KazumiDialog.dismiss();
                    },
                    child: Text(i.toString()),
                  )
                else
                  FilledButton.tonal(
                    onPressed: () async {
                      await widget.setPlaybackSpeed(i);
                      KazumiDialog.dismiss();
                    },
                    child: Text(i.toString()),
                  ),
              ]
            ],
          );
        }),
        actions: <Widget>[
          TextButton(
            onPressed: () => KazumiDialog.dismiss(),
            child: Text(
              '取消',
              style: TextStyle(color: Theme.of(context).colorScheme.outline),
            ),
          ),
          TextButton(
            onPressed: () async {
              await widget.setPlaybackSpeed(1.0);
              KazumiDialog.dismiss();
            },
            child: const Text('默认速度'),
          ),
        ],
      );
    });
  }

  void showForwardChange() {
    KazumiDialog.show(builder: (context) {
      String input = "";
      return AlertDialog(
        title: const Text('跳过秒数'),
        content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return TextField(
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            decoration: InputDecoration(
              floatingLabelBehavior: FloatingLabelBehavior.never,
              labelText: playerController.playback.buttonSkipTime.toString(),
            ),
            onChanged: (value) {
              input = value;
            },
          );
        }),
        actions: <Widget>[
          TextButton(
            onPressed: () => KazumiDialog.dismiss(),
            child: Text(
              '取消',
              style: TextStyle(color: Theme.of(context).colorScheme.outline),
            ),
          ),
          TextButton(
            onPressed: () async {
              if (input != "") {
                playerController.setButtonForwardTime(int.parse(input));
                KazumiDialog.dismiss();
              } else {
                KazumiDialog.dismiss();
              }
            },
            child: const Text('确定'),
          ),
        ],
      );
    });
  }

  @override
  void initState() {
    super.initState();
    playerController = widget.playerController;
    topOffsetAnimation = Tween<Offset>(
      begin: const Offset(0.0, -1.0),
      end: const Offset(0.0, 0.0),
    ).animate(CurvedAnimation(
      parent: widget.panelVisibilityController,
      curve: Curves.easeInOut,
    ));
    bottomOffsetAnimation = Tween<Offset>(
      begin: const Offset(0.0, 1.0),
      end: const Offset(0.0, 0.0),
    ).animate(CurvedAnimation(
      parent: widget.panelVisibilityController,
      curve: Curves.easeInOut,
    ));
    leftOffsetAnimation = Tween<Offset>(
      begin: const Offset(1.0, 0.0),
      end: const Offset(0.0, 0.0),
    ).animate(CurvedAnimation(
      parent: widget.panelVisibilityController,
      curve: Curves.easeInOut,
    ));
    cacheSvgIcons();
  }

  void cacheSvgIcons() {
    cachedDanmakuOffIcon = RepaintBoundary(
      child: SvgPicture.asset(
        'assets/images/danmaku_off.svg',
        height: _danmakuIconSize,
      ),
    );

    cachedDanmakuSettingIcon = RepaintBoundary(
      child: SvgPicture.asset(
        'assets/images/danmaku_setting.svg',
        height: _danmakuIconSize,
      ),
    );
  }

  Widget danmakuOnIcon(BuildContext context) {
    final colorHex = Theme.of(context)
        .colorScheme
        .primary
        .toARGB32()
        .toRadixString(16)
        .substring(2);

    if (cachedSvgString != colorHex) {
      cachedSvgString = colorHex;
      final svgString = danmakuOnSvg.replaceFirst('00AEEC', colorHex);
      cachedDanmakuOnIcon = RepaintBoundary(
        child: SvgPicture.string(
          svgString,
          height: _danmakuIconSize,
        ),
      );
    }

    return cachedDanmakuOnIcon!;
  }

  Widget _buildDanmakuToggleButton(BuildContext context) {
    return Observer(builder: (context) {
      final danmakuLoading = playerController.danmaku.danmakuLoading;
      final danmakuOn = playerController.danmaku.danmakuOn;
      return IconButton(
        color: Colors.white,
        icon: danmakuLoading
            ? SizedBox(
                width: _danmakuIconSize,
                height: _danmakuIconSize,
                child: CircularProgressIndicator(
                  strokeWidth: _loadingIndicatorStrokeWidth,
                ),
              )
            : (danmakuOn ? danmakuOnIcon(context) : cachedDanmakuOffIcon!),
        onPressed: danmakuLoading
            ? null
            : () {
                widget.handleDanmaku();
              },
        tooltip: danmakuLoading ? '弹幕加载中...' : (danmakuOn ? '关闭弹幕' : '打开弹幕'),
      );
    });
  }

  Widget forwardIcon() {
    return Tooltip(
      message: '快进${playerController.playback.buttonSkipTime}秒，长按修改时间',
      child: GestureDetector(
        onLongPress: () => showForwardChange(),
        child: IconButton(
          icon: Image.asset(
            'assets/images/forward_80.png',
            color: Colors.white,
            height: 24,
          ),
          onPressed: () {
            widget.skipOP();
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        AnimatedPositioned(
          duration: const Duration(seconds: 1),
          top: 0,
          left: 0,
          right: 0,
          child: Observer(builder: (context) {
            return Visibility(
              visible: !playerController.panel.lockPanel &&
                  (widget.disableAnimations
                      ? playerController.panel.showVideoController
                      : true),
              child: widget.disableAnimations
                  ? Container(
                      height: 50,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black45,
                            Colors.transparent,
                          ],
                        ),
                      ),
                    )
                  : SlideTransition(
                      position: topOffsetAnimation,
                      child: Container(
                        height: 50,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black45,
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
            );
          }),
        ),
        AnimatedPositioned(
          duration: const Duration(seconds: 1),
          bottom: 0,
          left: 0,
          right: 0,
          child: Observer(builder: (context) {
            return Visibility(
              visible: !playerController.panel.lockPanel &&
                  (widget.disableAnimations
                      ? playerController.panel.showVideoController
                      : true),
              child: widget.disableAnimations
                  ? Container(
                      height: 100,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black45,
                          ],
                        ),
                      ),
                    )
                  : SlideTransition(
                      position: bottomOffsetAnimation,
                      child: Container(
                        height: 100,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black45,
                            ],
                          ),
                        ),
                      ),
                    ),
            );
          }),
        ),
        Positioned(
          top: 25,
          child: Observer(builder: (context) {
            // PlayerSeekHud latches values only while visible, so skipping the
            // position reads when hidden keeps the 1s tick from rebuilding this.
            final visible = playerController.panel.showSeekTime;
            return PlayerSeekHud(
              visible: visible,
              currentPosition: visible
                  ? playerController.playback.currentPosition
                  : Duration.zero,
              playerPosition: visible
                  ? playerController.playback.playerPosition
                  : Duration.zero,
              duration:
                  visible ? playerController.playback.duration : Duration.zero,
              direction: playerController.panel.seekDirection,
              disableAnimations: widget.disableAnimations,
            );
          }),
        ),
        Positioned(
          top: 25,
          child: Observer(builder: (context) {
            return PlayerSpeedHud(
              visible: playerController.panel.showPlaySpeed,
              speed: playerController.playback.playerSpeed,
              disableAnimations: widget.disableAnimations,
            );
          }),
        ),
        Positioned(
          top: 25,
          child: Observer(builder: (context) {
            final showVolume = playerController.panel.showVolume;
            final showBrightness = playerController.panel.showBrightness;
            return PlayerAdjustmentHud(
              visible: showVolume || showBrightness,
              type: showVolume
                  ? PlayerAdjustmentHudType.volume
                  : PlayerAdjustmentHudType.brightness,
              value: showVolume
                  ? playerController.playback.volume
                  : playerController.panel.brightness,
              disableAnimations: widget.disableAnimations,
            );
          }),
        ),
        (isDesktop() || !videoPageController.isFullscreen)
            ? Container()
            : Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                child: Observer(builder: (context) {
                  return Visibility(
                    visible: widget.disableAnimations
                        ? playerController.panel.showVideoController
                        : true,
                    child: widget.disableAnimations
                        ? leftControlWidget
                        : SlideTransition(
                            position: leftOffsetAnimation,
                            child: leftControlWidget),
                  );
                }),
              ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: Observer(builder: (context) {
            return Visibility(
              visible: !playerController.panel.lockPanel &&
                  (widget.disableAnimations
                      ? playerController.panel.showVideoController
                      : true),
              child: widget.disableAnimations
                  ? topControlWidget
                  : SlideTransition(
                      position: topOffsetAnimation, child: topControlWidget),
            );
          }),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Observer(builder: (context) {
            return Visibility(
              visible: !playerController.panel.lockPanel &&
                  (widget.disableAnimations
                      ? playerController.panel.showVideoController
                      : true),
              child: widget.disableAnimations
                  ? bottomControlWidget
                  : SlideTransition(
                      position: bottomOffsetAnimation,
                      child: bottomControlWidget),
            );
          }),
        ),
      ],
    );
  }

  Widget get bottomControlWidget {
    return SafeArea(
      top: false,
      bottom: videoPageController.isFullscreen,
      left: videoPageController.isFullscreen,
      right: videoPageController.isFullscreen,
      child: PlayerPanelHoldMouseRegion(
        acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
        cursor: (videoPageController.isFullscreen &&
                !playerController.panel.showVideoController)
            ? SystemMouseCursors.none
            : SystemMouseCursors.basic,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Position reads stay inside these narrow Observers so the 1s
            // progress tick rebuilds only the bar and time text, not the
            // whole bottom bar.
            if (!isDesktop() && !isTablet())
              Container(
                padding: const EdgeInsets.only(left: 10.0, bottom: 10),
                child: Observer(builder: (context) {
                  return Text(
                    "${durationToString(playerController.playback.currentPosition)} / ${durationToString(playerController.playback.duration)}",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12.0,
                      fontFeatures: [
                        FontFeature.tabularFigures(),
                      ],
                    ),
                  );
                }),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Observer(builder: (context) {
                return ProgressBar(
                  thumbRadius: 8,
                  thumbGlowRadius: 18,
                  timeLabelLocation: isTablet()
                      ? TimeLabelLocation.sides
                      : TimeLabelLocation.none,
                  timeLabelTextStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 12.0,
                    fontFeatures: [
                      FontFeature.tabularFigures(),
                    ],
                  ),
                  progress: playerController.playback.currentPosition,
                  buffered: playerController.playback.buffer,
                  total: playerController.playback.duration,
                  onSeek: widget.handleProgressBarSeek,
                  onDragStart: (_) => widget.handleProgressBarDragStart(),
                  onDragUpdate: (details) => playerController.seeking
                      .updateInteractiveSeek(details.timeStamp),
                );
              }),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  IconButton(
                    tooltip: playerController.playback.playing ? '暂停' : '播放',
                    onPressed: () => playerController.playOrPause(),
                    icon: PlayPauseIcon(
                      iconColor: Colors.white,
                      playing: playerController.playback.playing,
                    ),
                  ),
                  if (videoPageController.isFullscreen ||
                      isTablet() ||
                      isDesktop())
                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.skip_next_rounded),
                      tooltip: '下一集',
                      onPressed: () => widget.handlePreNextEpisode('next'),
                    ),
                  if (isDesktop())
                    Container(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Observer(builder: (context) {
                        return Text(
                          "${durationToString(playerController.playback.currentPosition)} / ${durationToString(playerController.playback.duration)}",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16.0,
                            fontFeatures: [
                              FontFeature.tabularFigures(),
                            ],
                          ),
                        );
                      }),
                    ),
                  if (isDesktop())
                    Expanded(
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          bool isSpaceEnough = constraints.maxWidth > 600;
                          return Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                _buildDanmakuToggleButton(context),
                                IconButton(
                                  onPressed: () {
                                    showDanmakuSettingsSheet(
                                      context: context,
                                      danmakuController: playerController
                                          .danmaku.canvasController,
                                      onUpdateDanmakuSpeed:
                                          playerController.updateDanmakuSpeed,
                                      onTimelineOffsetChanged: playerController
                                          .danmaku
                                          .clearAndInvalidateScheduledDanmakus,
                                    );
                                  },
                                  color: Colors.white,
                                  icon: cachedDanmakuSettingIcon!,
                                  tooltip: '弹幕设置',
                                ),
                                if (isSpaceEnough) danmakuTextField,
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  if (!isDesktop()) ...[
                    IconButton(
                      color: Colors.white,
                      icon: playerController.danmaku.danmakuOn
                          ? danmakuOnIcon(context)
                          : cachedDanmakuOffIcon!,
                      onPressed: () {
                        widget.handleDanmaku();
                      },
                      tooltip:
                          playerController.danmaku.danmakuOn ? '关闭弹幕' : '打开弹幕',
                    ),
                    if (playerController.danmaku.danmakuOn) ...[
                      IconButton(
                        onPressed: () {
                          showDanmakuSettingsSheet(
                            context: context,
                            danmakuController:
                                playerController.danmaku.canvasController,
                            onUpdateDanmakuSpeed:
                                playerController.updateDanmakuSpeed,
                            onTimelineOffsetChanged: playerController
                                .danmaku.clearAndInvalidateScheduledDanmakus,
                          );
                        },
                        color: Colors.white,
                        icon: cachedDanmakuSettingIcon!,
                        tooltip: '弹幕设置',
                      ),
                      Expanded(child: danmakuTextField),
                    ],
                    if (!playerController.danmaku.danmakuOn) const Spacer(),
                  ],
                  PlayerPanelHoldMenuAnchor(
                    acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
                    onVisibilityChanged: widget.onMenuVisibilityChanged,
                    consumeOutsideTap: true,
                    builder: (BuildContext context, MenuController controller,
                        Widget? child) {
                      return TextButton(
                        onPressed: () {
                          if (controller.isOpen) {
                            controller.close();
                          } else {
                            controller.open();
                          }
                        },
                        child: const Text(
                          '超分辨率',
                          style: TextStyle(color: Colors.white),
                        ),
                      );
                    },
                    menuChildren: [
                      for (final mode in SuperResolutionMode.values)
                        MenuItemButton(
                          onPressed: () =>
                              widget.handleSuperResolutionChange(mode),
                          child: Container(
                            height: 48,
                            constraints: BoxConstraints(minWidth: 112),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                mode.label,
                                style: TextStyle(
                                  color: playerController
                                              .playback.superResolutionMode ==
                                          mode
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  PlayerPanelHoldMenuAnchor(
                    acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
                    onVisibilityChanged: widget.onMenuVisibilityChanged,
                    consumeOutsideTap: true,
                    builder: (BuildContext context, MenuController controller,
                        Widget? child) {
                      return TextButton(
                        onPressed: () {
                          if (controller.isOpen) {
                            controller.close();
                          } else {
                            controller.open();
                          }
                        },
                        child: Text(
                          playerController.playback.playerSpeed == 1.0
                              ? '倍速'
                              : '${playerController.playback.playerSpeed}x',
                          style: const TextStyle(color: Colors.white),
                        ),
                      );
                    },
                    menuChildren: [
                      for (final double i
                          in defaultPlaySpeedList) ...<MenuItemButton>[
                        MenuItemButton(
                          onPressed: () async {
                            await widget.setPlaybackSpeed(i);
                          },
                          child: Container(
                            height: 48,
                            constraints: BoxConstraints(minWidth: 112),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                '${i}x',
                                style: TextStyle(
                                  color: i ==
                                          playerController.playback.playerSpeed
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  PlayerPanelHoldMenuAnchor(
                    acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
                    onVisibilityChanged: widget.onMenuVisibilityChanged,
                    consumeOutsideTap: true,
                    builder: (BuildContext context, MenuController controller,
                        Widget? child) {
                      return IconButton(
                        onPressed: () {
                          if (controller.isOpen) {
                            controller.close();
                          } else {
                            controller.open();
                          }
                        },
                        icon: const Icon(
                          Icons.aspect_ratio_rounded,
                          color: Colors.white,
                        ),
                        tooltip: '视频比例',
                      );
                    },
                    menuChildren: [
                      for (final aspectRatioMode in PlayerAspectRatio.values)
                        MenuItemButton(
                          onPressed: () => playerController
                              .panel.aspectRatioMode = aspectRatioMode,
                          child: Container(
                            height: 48,
                            constraints: BoxConstraints(minWidth: 112),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                aspectRatioMode.label,
                                style: TextStyle(
                                  color: aspectRatioMode ==
                                          playerController.panel.aspectRatioMode
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  (!videoPageController.isFullscreen &&
                          !isTablet() &&
                          !isDesktop())
                      ? Container()
                      : IconButton(
                          color: Colors.white,
                          icon: const Icon(Icons.menu_open_rounded),
                          tooltip: '选集面板',
                          onPressed: () {
                            widget.toggleMenu();
                          },
                        ),
                  (isTablet() &&
                          videoPageController.isFullscreen &&
                          MediaQuery.of(context).size.height <
                              MediaQuery.of(context).size.width)
                      ? Container()
                      : IconButton(
                          color: Colors.white,
                          icon: Icon(videoPageController.isFullscreen
                              ? Icons.fullscreen_exit_rounded
                              : Icons.fullscreen_rounded),
                          tooltip:
                              videoPageController.isFullscreen ? '退出全屏' : '全屏',
                          onPressed: () {
                            widget.handleFullscreen();
                          },
                        ),
                ],
              ),
            ),
            if (isTablet() || isDesktop()) const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Widget get topControlWidget {
    return EmbeddedNativeControlArea(
      requireOffset: !videoPageController.isFullscreen,
      child: SafeArea(
        top: false,
        bottom: false,
        left: videoPageController.isFullscreen,
        right: videoPageController.isFullscreen,
        child: PlayerPanelHoldMouseRegion(
          acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
          cursor: (videoPageController.isFullscreen &&
                  !playerController.panel.showVideoController)
              ? SystemMouseCursors.none
              : SystemMouseCursors.basic,
          child: Row(
            children: [
              IconButton(
                color: Colors.white,
                icon: const Icon(Icons.arrow_back_rounded),
                tooltip: '返回',
                onPressed: () {
                  widget.onBackPressed(context);
                },
              ),
              Expanded(
                child: dtb.DragToMoveArea(
                  child: Text(
                    ' ${videoPageController.title} [${videoPageController.roadList[videoPageController.selectedEpisode.road].identifier[videoPageController.selectedEpisode.episode - 1]}]',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize:
                          Theme.of(context).textTheme.titleMedium!.fontSize,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ),
              forwardIcon(),
              if ((isDesktop() && !videoPageController.isFullscreen) ||
                  Platform.isAndroid)
                IconButton(
                  onPressed: () async {
                    if (isDesktop()) {
                      if (videoPageController.isPip) {
                        await PipUtils.exitDesktopPIPWindow();
                      } else {
                        await PipUtils.enterDesktopPIPWindow(
                          width: playerController.debug.playerWidth,
                          height: playerController.debug.playerHeight,
                        );
                      }
                      videoPageController.isPip = !videoPageController.isPip;
                      return;
                    }
                    await widget.enterAndroidPictureInPicture();
                  },
                  tooltip: '画中画',
                  icon: const Icon(
                    Icons.picture_in_picture,
                    color: Colors.white,
                  ),
                ),
              PlayerPanelHoldCollectButton(
                acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
                bangumiItem: videoPageController.bangumiItem,
              ),
              PlayerPanelHoldMenuAnchor(
                acquirePlayerPanelHold: widget.acquirePlayerPanelHold,
                onVisibilityChanged: widget.onMenuVisibilityChanged,
                consumeOutsideTap: true,
                builder: (BuildContext context, MenuController controller,
                    Widget? child) {
                  return IconButton(
                    onPressed: () {
                      if (controller.isOpen) {
                        controller.close();
                      } else {
                        controller.open();
                      }
                    },
                    tooltip: '更多选项',
                    icon: const Icon(
                      Icons.more_vert,
                      color: Colors.white,
                    ),
                  );
                },
                menuChildren: [
                  MenuItemButton(
                    onPressed: () {
                      widget.showDanmakuSwitch();
                    },
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("弹幕切换"),
                      ),
                    ),
                  ),
                  MenuItemButton(
                    onPressed: () {
                      widget.showVideoInfo();
                    },
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("视频详情"),
                      ),
                    ),
                  ),
                  MenuItemButton(
                    onPressed: () {
                      bool needRestart = playerController.playback.playing;
                      playerController.pause();
                      RemotePlay()
                          .castVideo(playerController.videoUrl,
                              videoPageController.currentPlugin.referer)
                          .whenComplete(() {
                        if (mounted && needRestart) {
                          playerController.play();
                        }
                      });
                    },
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("远程投屏"),
                      ),
                    ),
                  ),
                  MenuItemButton(
                    onPressed: () {
                      playerController.launchExternalPlayer();
                    },
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("外部播放"),
                      ),
                    ),
                  ),
                  SubmenuButton(
                    menuChildren: [
                      MenuItemButton(
                        onPressed: () {
                          TimedShutdownService().cancel();
                        },
                        child: Container(
                          height: 48,
                          constraints: BoxConstraints(minWidth: 112),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "不开启",
                              style: TextStyle(
                                color: !TimedShutdownService().isActive
                                    ? Theme.of(context).colorScheme.primary
                                    : null,
                              ),
                            ),
                          ),
                        ),
                      ),
                      for (final int minutes in [15, 30, 60])
                        MenuItemButton(
                          onPressed: () {
                            TimedShutdownService().start(minutes,
                                onExpired: widget.pauseForTimedShutdown);
                            KazumiDialog.showToast(
                                message:
                                    '已设置 ${TimedShutdownService().formatMinutesToDisplay(minutes)} 后定时关闭');
                          },
                          child: Container(
                            height: 48,
                            constraints: BoxConstraints(minWidth: 112),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "$minutes 分钟",
                                style: TextStyle(
                                  color: TimedShutdownService().setMinutes ==
                                          minutes
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                      MenuItemButton(
                        onPressed: () {
                          TimedShutdownService.showCustomTimerDialog(
                            onExpired: widget.pauseForTimedShutdown,
                          );
                        },
                        child: Container(
                          height: 48,
                          constraints: BoxConstraints(minWidth: 112),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text("自定义"),
                          ),
                        ),
                      ),
                    ],
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: ValueListenableBuilder<int>(
                          valueListenable:
                              TimedShutdownService().remainingSecondsNotifier,
                          builder: (context, remainingSeconds, child) {
                            return Text(
                              remainingSeconds > 0
                                  ? "定时关闭 (${TimedShutdownService().formatRemainingTime()})"
                                  : "定时关闭",
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  MenuItemButton(
                    onPressed: () {
                      widget.showSyncPlayPanel();
                    },
                    child: Container(
                      height: 48,
                      constraints: BoxConstraints(minWidth: 112),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("一起看"),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget get leftControlWidget {
    return SafeArea(
      top: false,
      bottom: false,
      left: videoPageController.isFullscreen,
      right: videoPageController.isFullscreen,
      child: Column(
        children: [
          const Spacer(),
          (playerController.panel.lockPanel)
              ? Container()
              : IconButton(
                  icon: const Icon(
                    Icons.photo_camera_outlined,
                    color: Colors.white,
                  ),
                  tooltip: '截图',
                  onPressed: () {
                    widget.handleScreenShot();
                  },
                ),
          IconButton(
            icon: Icon(
              playerController.panel.lockPanel
                  ? Icons.lock_outline
                  : Icons.lock_open,
              color: Colors.white,
            ),
            tooltip: playerController.panel.lockPanel ? '解锁面板' : '锁定面板',
            onPressed: () {
              playerController.panel.lockPanel =
                  !playerController.panel.lockPanel;
            },
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
